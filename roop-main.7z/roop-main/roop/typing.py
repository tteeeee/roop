from typing import Any

from insightface.app.common import Face
import numpy

Face = Face
Frame = numpy.ndarray[Any, Any]
